<?php
/**
 * @package WordPress
 * @subpackage Oakland
 * @since Oakland 1.0
 * 
 * Slider Manager Operator
 * Created by CMSMasters
 * 
 */


require_once('../../../../../wp-load.php');

$slider = new cmsmsSliderController();

?>