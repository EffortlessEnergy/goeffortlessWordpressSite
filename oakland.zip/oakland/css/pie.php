<?php
/**
 * @package WordPress
 * @subpackage Oakland
 * @since Oakland 1.0
 * 
 * Include pie.htc File for IE < 9
 * Changed by CMSMasters
 * 
 */


header('Content-type: text/x-component');
include('pie.htc');

?>